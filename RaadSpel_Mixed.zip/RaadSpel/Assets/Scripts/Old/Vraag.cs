﻿//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;

//[System.Serializable]
//public class Vraag {

//    public int id;
//    public string vraag;
//    public int fase_id;
//    public List<antwoorden> antwoorden;

//}
