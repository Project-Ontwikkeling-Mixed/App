﻿//using UnityEngine;
//using System.Collections;
//using System.Collections.Generic;
//using System;

//[Serializable]
//public class antwoorden {
//    public int id;
//    public string antwoord;
//    public int inspraakvraag_id;
//    public int aantal_gekozen;


    //public int Id
    //{
    //    get
    //    {
    //        return id;
    //    }
    //    set
    //    {
    //        id = value;
    //    }
    //}

    //public string Antwoord
    //{
    //    get
    //    {
    //        return antwoord;
    //    }
    //    set
    //    {
    //        antwoord = value;
    //    }
    //}
    //public int Inspraakvraag_id
    //{
    //    get
    //    {
    //        return inspraakvraag_id;
    //    }
    //    set
    //    {
    //        inspraakvraag_id = value;
    //    }
    //}
    //public int Aantal_gekozen
    //{
    //    get
    //    {
    //        return aantal_gekozen;
    //    }
    //    set
    //    {
    //        aantal_gekozen = value;
    //    }
    //}


//}
